# real-estate

Open a terminal and type
```
npm install
npm run start
